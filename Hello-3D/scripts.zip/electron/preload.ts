import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('electronAPI', {
  setIgnoreMouse: (ignore: boolean) => ipcRenderer.send('set-ignore-mouse', ignore),
  openSettings: () => ipcRenderer.send('open-settings'),
  isSettingsWindow: () => new URLSearchParams(window.location.search).get('settings') === 'true',
  sendSettings: (settings: unknown) => ipcRenderer.send('update-settings', settings),
  onSettingsUpdated: (callback: (settings: unknown) => void) => {
    ipcRenderer.on('settings-updated', (_, settings) => callback(settings))
  },
  setEditMode: (enabled: boolean) => ipcRenderer.send('set-edit-mode', enabled),
  closeSettings: () => ipcRenderer.send('close-settings'),
  startDrag: (x: number, y: number) => ipcRenderer.send('start-drag', { x, y }),
  moveDrag: (x: number, y: number) => ipcRenderer.send('move-drag', { x, y }),
  updateShortcuts: (shortcuts: { toggle: string, settings: string }) => ipcRenderer.send('update-shortcuts', shortcuts),
})