"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("electronAPI", {
  setIgnoreMouse: (ignore) => electron.ipcRenderer.send("set-ignore-mouse", ignore),
  openSettings: () => electron.ipcRenderer.send("open-settings"),
  isSettingsWindow: () => new URLSearchParams(window.location.search).get("settings") === "true",
  sendSettings: (settings) => electron.ipcRenderer.send("update-settings", settings),
  onSettingsUpdated: (callback) => {
    electron.ipcRenderer.on("settings-updated", (_, settings) => callback(settings));
  },
  setEditMode: (enabled) => electron.ipcRenderer.send("set-edit-mode", enabled),
  closeSettings: () => electron.ipcRenderer.send("close-settings"),
  startDrag: (x, y) => electron.ipcRenderer.send("start-drag", { x, y }),
  moveDrag: (x, y) => electron.ipcRenderer.send("move-drag", { x, y }),
  updateShortcuts: (shortcuts) => electron.ipcRenderer.send("update-shortcuts", shortcuts)
});
